import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './pages/Dashboard';
import { Financial } from './pages/Financial';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#0C0B1F]" style={{
        backgroundImage: 'url(https://astrom.com.br/images/bg-2000.webp)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}>
        <Sidebar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/financial" element={<Financial />} />
          {/* Add other routes as needed */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;