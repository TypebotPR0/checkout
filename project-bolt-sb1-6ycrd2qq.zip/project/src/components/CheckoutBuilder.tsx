import React from 'react';
import { useCheckoutStore } from '../store/checkoutStore';
import { Settings, Layout, Palette } from 'lucide-react';

export const CheckoutBuilder: React.FC = () => {
  const { theme, updateTheme } = useCheckoutStore();

  return (
    <div className="fixed right-0 top-0 h-screen w-80 bg-[#0C0B1F] border-l border-gray-800 p-4 overflow-y-auto">
      <div className="space-y-6">
        <div className="flex items-center gap-2 mb-6">
          <Settings className="w-5 h-5" />
          <h2 className="text-xl font-bold">Checkout Builder</h2>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <Layout className="w-4 h-4" />
              Layout
            </label>
            <select
              value={theme.layout}
              onChange={(e) => updateTheme({ layout: e.target.value as 'single' | 'two-column' })}
              className="w-full bg-gray-900 border border-gray-700 rounded-md p-2"
            >
              <option value="single">Single Column</option>
              <option value="two-column">Two Columns</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <Palette className="w-4 h-4" />
              Primary Color
            </label>
            <input
              type="color"
              value={theme.primaryColor}
              onChange={(e) => updateTheme({ primaryColor: e.target.value })}
              className="w-full h-10 rounded-md cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <label>Button Style</label>
            <select
              value={theme.buttonStyle}
              onChange={(e) => updateTheme({ buttonStyle: e.target.value as 'solid' | 'outline' })}
              className="w-full bg-gray-900 border border-gray-700 rounded-md p-2"
            >
              <option value="solid">Solid</option>
              <option value="outline">Outline</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};