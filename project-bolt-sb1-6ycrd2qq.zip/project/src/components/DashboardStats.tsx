import React from 'react';
import { DashboardStats } from '../types/dashboard';

interface StatsCardProps {
  title: string;
  value: string | number;
  className?: string;
}

const StatsCard: React.FC<StatsCardProps> = ({ title, value, className = '' }) => (
  <div className={`bg-opacity-3 backdrop-blur-lg bg-white/[0.03] rounded-lg p-6 ${className}`}>
    <h3 className="text-gray-400 text-sm mb-2">{title}</h3>
    <p className="text-2xl font-bold text-white">{value}</p>
  </div>
);

interface DashboardStatsProps {
  stats: DashboardStats;
}

export const DashboardStatsView: React.FC<DashboardStatsProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatsCard title="Faturamento bruto" value={`R$ ${stats.grossRevenue.toFixed(2)}`} />
      <StatsCard title="Faturamento líquido" value={`R$ ${stats.netRevenue.toFixed(2)}`} />
      <StatsCard title="Total de vendas" value={stats.totalSales} />
      <StatsCard title="Vendas aprovadas" value={stats.approvedSales} />
      <StatsCard title="Faturamento líquido - PIX" value={`R$ ${stats.pixRevenue.toFixed(2)}`} />
      <StatsCard title="Faturamento líquido - Cartão" value={`R$ ${stats.cardRevenue.toFixed(2)}`} />
      <StatsCard 
        title="Taxas de conversão" 
        value={`${stats.conversionRate.toFixed(2)}%`}
        className="col-span-2"
      />
    </div>
  );
};