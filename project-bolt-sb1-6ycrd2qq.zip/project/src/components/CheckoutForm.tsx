import React from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { useCheckoutStore } from '../store/checkoutStore';

export const CheckoutForm: React.FC = () => {
  const stripe = useStripe();
  const elements = useElements();
  const theme = useCheckoutStore((state) => state.theme);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!stripe || !elements) return;

    const { error, paymentMethod } = await stripe.createPaymentMethod({
      type: 'card',
      card: elements.getElement(CardElement)!,
    });

    if (error) {
      console.log('[error]', error);
    } else {
      console.log('[PaymentMethod]', paymentMethod);
      // Handle successful payment here
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-opacity-3 backdrop-blur-lg bg-white/[0.03] rounded-lg p-6 shadow-lg">
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Card Details</label>
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: theme.textColor,
                  '::placeholder': {
                    color: `${theme.textColor}80`,
                  },
                },
              },
            }}
            className="p-4 rounded-md border border-gray-700"
          />
        </div>
        <button
          type="submit"
          disabled={!stripe}
          className="w-full py-3 px-4 rounded-md bg-indigo-600 text-white font-medium hover:bg-indigo-700 transition-colors"
        >
          Pay Now
        </button>
      </div>
    </form>
  );
};