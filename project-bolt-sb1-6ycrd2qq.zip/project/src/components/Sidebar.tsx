import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home,
  ShoppingBag,
  RefreshCcw,
  Zap,
  Paintbrush,
  Users,
  ShoppingCart,
  DollarSign,
  Clipboard,
  RefreshCw,
  FileText,
  Link as LinkIcon
} from 'lucide-react';

const NavItem = ({ to, icon: Icon, children }: { to: string; icon: any; children: React.ReactNode }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link
      to={to}
      className={`flex items-center gap-3 px-4 py-3 text-sm rounded-lg transition-colors ${
        isActive
          ? 'bg-pink-600 text-white'
          : 'text-gray-400 hover:bg-white/[0.03] hover:text-white'
      }`}
    >
      <Icon className="w-5 h-5" />
      {children}
    </Link>
  );
};

export const Sidebar = () => {
  return (
    <div className="fixed left-0 top-0 h-screen w-64 bg-[#0C0B1F] border-r border-gray-800 p-4">
      <div className="flex items-center gap-2 px-4 mb-8">
        <div className="w-8 h-8 bg-pink-600 rounded-lg flex items-center justify-center">
          <Zap className="w-5 h-5 text-white" />
        </div>
        <span className="text-xl font-bold text-white">Dashboard</span>
      </div>

      <nav className="space-y-1">
        <NavItem to="/" icon={Home}>Página Inicial</NavItem>
        <NavItem to="/sales" icon={ShoppingBag}>Minhas Vendas</NavItem>
        <NavItem to="/products" icon={ShoppingCart}>Produtos</NavItem>
        <NavItem to="/recovery" icon={RefreshCcw}>Recuperação</NavItem>
        <NavItem to="/upsell" icon={Zap}>Upsell 1 Click</NavItem>
        <NavItem to="/builder" icon={Paintbrush}>Checkout Builder</NavItem>
        <NavItem to="/affiliates" icon={Users}>Minhas Afiliações</NavItem>
        <NavItem to="/marketplace" icon={ShoppingCart}>Marketplace</NavItem>
        <NavItem to="/financial" icon={DollarSign}>Financeiro</NavItem>
        <NavItem to="/subscriptions" icon={Clipboard}>Assinaturas</NavItem>
        <NavItem to="/refunds" icon={RefreshCw}>Reembolsos</NavItem>
        <NavItem to="/reports" icon={FileText}>Relatórios</NavItem>
        <NavItem to="/integrations" icon={LinkIcon}>Integrações</NavItem>
      </nav>
    </div>
  );
};