import React from 'react';

interface Stats {
  grossRevenue: number;
  netRevenue: number;
  salesCount: number;
  conversionRate: number;
}

interface Props {
  stats: Stats;
}

const StatsCard = ({ title, value }: { title: string; value: string }) => (
  <div className="bg-opacity-3 backdrop-blur-lg bg-white/[0.03] rounded-lg p-6">
    <h3 className="text-gray-400 text-sm mb-2">{title}</h3>
    <p className="text-2xl font-bold text-white">{value}</p>
  </div>
);

export const StatsOverview: React.FC<Props> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatsCard title="Faturamento bruto" value={`R$ ${stats.grossRevenue.toFixed(2)}`} />
      <StatsCard title="Faturamento líquido" value={`R$ ${stats.netRevenue.toFixed(2)}`} />
      <StatsCard title="Qtd. Vendas" value={stats.salesCount.toString()} />
      <StatsCard title="Taxa de conversão" value={`${stats.conversionRate.toFixed(2)}%`} />
    </div>
  );
};