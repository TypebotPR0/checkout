import React from 'react';

export const SalesTable = () => {
  return (
    <div className="bg-opacity-3 backdrop-blur-lg bg-white/[0.03] rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-white">Vendas</h2>
        <input
          type="text"
          placeholder="Pesquisar..."
          className="bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:border-pink-600"
        />
      </div>

      <table className="w-full">
        <thead>
          <tr className="text-left text-gray-400 text-sm">
            <th className="pb-4">AÇÕES</th>
            <th className="pb-4">STATUS</th>
            <th className="pb-4">DATA</th>
            <th className="pb-4">FORMA PAGTO.</th>
            <th className="pb-4">TIPO DO PRODUTO</th>
            <th className="pb-4">COMPRADOR</th>
            <th className="pb-4">PRODUTO</th>
            <th className="pb-4">VALOR</th>
            <th className="pb-4">SUA COMISSÃO</th>
          </tr>
        </thead>
        <tbody className="text-white">
          {/* Add table rows here when you have data */}
        </tbody>
      </table>

      <div className="flex justify-between items-center mt-6">
        <button className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors">
          Anterior
        </button>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors">
            1
          </button>
        </div>
        <button className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors">
          Próximo
        </button>
      </div>
    </div>
  );
};