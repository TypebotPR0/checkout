import React from 'react';
import { X } from 'lucide-react';
import { UpsellProduct } from '../types/checkout';

interface UpsellModalProps {
  product: UpsellProduct;
  onAccept: () => void;
  onDecline: () => void;
}

export const UpsellModal: React.FC<UpsellModalProps> = ({ product, onAccept, onDecline }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-[#0C0B1F] rounded-lg p-6 max-w-md w-full relative backdrop-blur-lg bg-opacity-95">
        <button
          onClick={onDecline}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X size={24} />
        </button>
        
        <div className="text-center">
          <h3 className="text-xl font-bold mb-4">Special Offer!</h3>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-48 object-cover rounded-lg mb-4"
          />
          <p className="text-lg mb-2">{product.name}</p>
          <p className="text-gray-300 mb-4">{product.description}</p>
          <p className="text-2xl font-bold mb-6">${product.price}</p>
          
          <div className="space-y-3">
            <button
              onClick={onAccept}
              className="w-full py-3 px-4 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
            >
              Add to Order
            </button>
            <button
              onClick={onDecline}
              className="w-full py-3 px-4 text-gray-300 hover:text-white transition-colors"
            >
              No, thanks
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};