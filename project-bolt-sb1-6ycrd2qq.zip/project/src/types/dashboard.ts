export interface DashboardStats {
  grossRevenue: number;
  netRevenue: number;
  totalSales: number;
  approvedSales: number;
  cardRevenue: number;
  pixRevenue: number;
  conversionRate: number;
}

export interface Sale {
  id: string;
  status: 'approved' | 'pending' | 'rejected';
  date: string;
  paymentMethod: 'card' | 'pix';
  productType: string;
  buyer: string;
  product: string;
  value: number;
  commission: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  category: string;
  type: string;
  salesUrl: string;
  deliveryType: 'email' | 'download' | 'physical';
  additionalInfo: string;
  supportEmail: string;
  warranty: string;
  status: 'active' | 'inactive';
}