export interface BankAccount {
  id: string;
  bank: string;
  agency: string;
  accountNumber: string;
  pixKey?: string;
  status: 'active' | 'pending' | 'inactive';
}

export interface WithdrawalRequest {
  id: string;
  amount: number;
  bankAccountId: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  fee: number;
  netAmount: number;
}

export interface FinancialStats {
  availableBalance: number;
  pendingBalance: number;
  financialReserve: number;
}