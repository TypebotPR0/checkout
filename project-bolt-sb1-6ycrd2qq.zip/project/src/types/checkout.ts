export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
}

export interface UpsellProduct extends Product {
  originalProductId: string;
}

export interface CheckoutTheme {
  primaryColor: string;
  backgroundColor: string;
  textColor: string;
  buttonStyle: 'solid' | 'outline';
  layout: 'single' | 'two-column';
}