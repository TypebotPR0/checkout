import { create } from 'zustand';
import { Product, UpsellProduct, CheckoutTheme } from '../types/checkout';

interface CheckoutState {
  products: Product[];
  upsellProducts: UpsellProduct[];
  theme: CheckoutTheme;
  setProducts: (products: Product[]) => void;
  setUpsellProducts: (products: UpsellProduct[]) => void;
  updateTheme: (theme: Partial<CheckoutTheme>) => void;
}

export const useCheckoutStore = create<CheckoutState>((set) => ({
  products: [],
  upsellProducts: [],
  theme: {
    primaryColor: '#6366f1',
    backgroundColor: '#0C0B1F',
    textColor: '#ffffff',
    buttonStyle: 'solid',
    layout: 'two-column',
  },
  setProducts: (products) => set({ products }),
  setUpsellProducts: (products) => set({ upsellProducts }),
  updateTheme: (theme) => set((state) => ({ theme: { ...state.theme, ...theme } })),
}));