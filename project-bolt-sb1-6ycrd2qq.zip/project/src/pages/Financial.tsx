import React, { useState } from 'react';
import { BankAccount, FinancialStats } from '../types/financial';
import { AlertTriangle } from 'lucide-react';

const mockStats: FinancialStats = {
  availableBalance: 0.62,
  pendingBalance: 0.00,
  financialReserve: 0.00,
};

const mockBankAccounts: BankAccount[] = [{
  id: '1',
  bank: '260 - Nu Pagamentos S.A (Nubank)',
  agency: '0001-0',
  accountNumber: '0000082632684-3',
  pixKey: '52.896.253/0001-99',
  status: 'active',
}];

export const Financial = () => {
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [showAddAccountModal, setShowAddAccountModal] = useState(false);

  return (
    <div className="p-8 ml-64">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold text-white mb-8">Financeiro</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <button
            onClick={() => setShowWithdrawModal(true)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-lg transition-colors"
          >
            Solicitar saque
          </button>
          <button
            onClick={() => setShowAddAccountModal(true)}
            className="bg-pink-600 hover:bg-pink-700 text-white py-4 rounded-lg transition-colors"
          >
            Cadastrar conta bancária
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-opacity-3 backdrop-blur-lg bg-white/[0.03] rounded-lg p-6">
            <h3 className="text-gray-400 text-sm mb-2">Disponível para saque</h3>
            <p className="text-2xl font-bold text-white">R$ {mockStats.availableBalance.toFixed(2)}</p>
          </div>
          <div className="bg-opacity-3 backdrop-blur-lg bg-white/[0.03] rounded-lg p-6">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-gray-400 text-sm mb-2">Saldo pendente</h3>
                <p className="text-2xl font-bold text-white">R$ {mockStats.pendingBalance.toFixed(2)}</p>
              </div>
              <button className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm">
                Antecipar
              </button>
            </div>
          </div>
          <div className="bg-opacity-3 backdrop-blur-lg bg-white/[0.03] rounded-lg p-6">
            <h3 className="text-gray-400 text-sm mb-2">Reserva financeira</h3>
            <p className="text-2xl font-bold text-white">R$ {mockStats.financialReserve.toFixed(2)}</p>
          </div>
        </div>

        <div className="bg-opacity-3 backdrop-blur-lg bg-white/[0.03] rounded-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-white">Contas cadastradas</h2>
            <input
              type="text"
              placeholder="Pesquisar..."
              className="bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:border-pink-600"
            />
          </div>

          <table className="w-full">
            <thead>
              <tr className="text-left text-gray-400 text-sm">
                <th className="pb-4">BANCO</th>
                <th className="pb-4">AGÊNCIA</th>
                <th className="pb-4">CONTA</th>
                <th className="pb-4">CHAVE PIX</th>
                <th className="pb-4">STATUS</th>
                <th className="pb-4">AÇÕES</th>
              </tr>
            </thead>
            <tbody className="text-white">
              {mockBankAccounts.map((account) => (
                <tr key={account.id} className="border-t border-gray-800">
                  <td className="py-4">{account.bank}</td>
                  <td className="py-4">{account.agency}</td>
                  <td className="py-4">{account.accountNumber}</td>
                  <td className="py-4">{account.pixKey}</td>
                  <td className="py-4">
                    <span className="px-2 py-1 rounded text-xs bg-emerald-500/20 text-emerald-500">
                      {account.status}
                    </span>
                  </td>
                  <td className="py-4">
                    <button className="text-pink-600 hover:text-pink-500 mr-2">Editar</button>
                    <button className="text-red-600 hover:text-red-500">Excluir</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showWithdrawModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-[#0C0B1F] rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-white">Solicitar saque</h3>
                <button onClick={() => setShowWithdrawModal(false)} className="text-gray-400 hover:text-white">
                  ×
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Selecione a conta</label>
                  <select className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white">
                    <option value="">Selecione uma conta</option>
                    {mockBankAccounts.map(account => (
                      <option key={account.id} value={account.id}>
                        {account.bank} - {account.accountNumber}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1">Valor do saque</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">R$</span>
                    <input
                      type="number"
                      className="w-full bg-gray-900 border border-gray-700 rounded-lg pl-12 pr-4 py-2 text-white"
                      placeholder="0,00"
                    />
                  </div>
                  <div className="mt-2 text-sm">
                    <div className="flex justify-between text-gray-400">
                      <span>Saldo da conta:</span>
                      <span>R$ {mockStats.availableBalance.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Taxa de saque:</span>
                      <span>R$ 10,00</span>
                    </div>
                    <div className="flex justify-between text-emerald-500 font-medium mt-1">
                      <span>Valor líquido do saque:</span>
                      <span>R$ 0,00</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1">Digite sua senha</label>
                  <input
                    type="password"
                    className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white"
                  />
                </div>

                <button className="w-full bg-pink-600 hover:bg-pink-700 text-white py-3 rounded-lg transition-colors">
                  Solicitar Saque
                </button>
              </div>
            </div>
          </div>
        )}

        {showAddAccountModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-[#0C0B1F] rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-white">Crie sua conta bancária</h3>
                <button onClick={() => setShowAddAccountModal(false)} className="text-gray-400 hover:text-white">
                  ×
                </button>
              </div>

              <div className="bg-yellow-900/20 border border-yellow-700/50 rounded-lg p-4 mb-6">
                <div className="flex gap-2">
                  <AlertTriangle className="w-5 h-5 text-yellow-500 flex-shrink-0" />
                  <p className="text-sm text-yellow-500">
                    A conta cadastrada deve ser da sua titularidade, para não ter problemas na hora de sacar!
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Banco</label>
                  <select className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white">
                    <option value="">Selecione o banco</option>
                  </select>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm text-gray-400 mb-1">Agência</label>
                    <input
                      type="text"
                      className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Dígito</label>
                    <input
                      type="text"
                      className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm text-gray-400 mb-1">Conta bancária</label>
                    <input
                      type="text"
                      className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Dígito</label>
                    <input
                      type="text"
                      className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1">Chave Pix (se houver)</label>
                  <input
                    type="text"
                    className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white"
                  />
                </div>

                <button className="w-full bg-pink-600 hover:bg-pink-700 text-white py-3 rounded-lg transition-colors">
                  Criar Conta
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};