import React from 'react';
import { DashboardStatsView } from '../components/DashboardStats';
import { SalesTable } from '../components/SalesTable';

const mockStats = {
  grossRevenue: 0.00,
  netRevenue: 0.00,
  totalSales: 0,
  approvedSales: 0,
  cardRevenue: 0.00,
  pixRevenue: 0.00,
  conversionRate: 0.00,
};

const mockSales: Sale[] = [];

export const Dashboard = () => {
  return (
    <div className="p-8 ml-64">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <div className="flex items-center gap-4">
            <select className="bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white">
              <option>Hoje</option>
              <option>Última semana</option>
              <option>Último mês</option>
            </select>
          </div>
        </div>

        <DashboardStatsView stats={mockStats} />
        <SalesTable sales={mockSales} />
      </div>
    </div>
  );
};